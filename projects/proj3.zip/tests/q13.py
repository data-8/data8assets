test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> most_murderous(1970)
          ['North Carolina', 'Alaska', 'Florida', 'South Carolina', 'Georgia']
          >>> most_murderous(1980)
          ['Florida', 'Mississippi', 'Louisiana', 'Texas', 'Nevada']
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
