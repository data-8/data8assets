test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> print(poverty_counts)
          SMSA name                  | False | True
          Oakland                    | 316   | 71
          San Francisco              | 253   | 52
          San Jose                   | 216   | 32
          Santa Rosa - Petaluma      | 31    | 2
          Vallejo - Fairfield - Napa | 34    | 7
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
