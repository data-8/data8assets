test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> most_democratic_state(1932)
          'South Carolina'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> most_democratic_state(1940)
          'Mississippi'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> most_democratic_state(1948)
          'Texas'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> most_democratic_state(1952)
          'Georgia'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> most_democratic_state(1960)
          'Rhode Island'
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> most_democratic_state(2012)
          'DC'
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
