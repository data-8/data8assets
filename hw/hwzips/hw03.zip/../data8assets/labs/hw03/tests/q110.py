test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> columns[1]
          'state'
          >>> 
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'from datascience import *',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}