test = {
  'name': 'Question 3.3.1',
  'points': 4,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> 0 <= proportion_correct <= 1
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
