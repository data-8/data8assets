test = {
  'name': 'Question 1.1.3',
  'points': 2,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> unstemmed_singl.startswith('singl')
          True
          >>> len(unstemmed_singl) > len('singl')
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
