test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Your answer looks pretty far off -- maybe you're using the wrong formula?
          >>> round(roughly_e, 1)
          2.7
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> round(roughly_e, 4)
          2.7183
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
