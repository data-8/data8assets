test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> round(sum(celsius_temperature_ranges))
          768487.0
          >>> len(celsius_temperature_ranges)
          65000
          >>> celsius_temperature_ranges.item(1)
          10.0
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
