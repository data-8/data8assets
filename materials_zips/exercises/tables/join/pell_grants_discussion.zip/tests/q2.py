test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> print(with_names.take(range(49, 59)))
          State (abbreviated) | Pell proportion | State
          NH                  | 0.32379         | New Hampshire
          MA                  | 0.321476        | Massachusetts
          WA                  | 0.318926        | Washington
          NE                  | 0.318924        | Nebraska
          DE                  | 0.318162        | Delaware
          DC                  | 0.301792        | District of Columbia
          VT                  | 0.298559        | Vermont
          AK                  | 0.263879        | Alaska
          WY                  | 0.259099        | Wyoming
          ND                  | 0.256818        | North Dakota
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
