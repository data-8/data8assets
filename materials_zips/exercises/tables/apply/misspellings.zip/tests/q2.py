test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> essay_filenames
          Name
          a_desk_book_of_errors_in_english.txt
          how_to_write_letters.txt
          lippincotts_horn_ashbaugh_speller.txt
          news_writing.txt
          the_letters_of_henry_james_volume_I.txt
          the_virginian.txt
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
