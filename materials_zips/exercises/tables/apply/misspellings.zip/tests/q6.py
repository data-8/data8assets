test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> misspelled_lines
          Line
          person whose name has been mispeled never quite forgives ...
          mispeled names, misplaced words and phrases, and even in ...
          printer set up slangy, mispeled, or improperly capitaliz ...
          bad spelling, because the meaning of a mispeled word usu ...
              mispel
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
