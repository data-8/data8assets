test = {
  'name': 'Question 5_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # Hint: shortest is a number between 40 and 50.
          >>> 40 <= shortest <= 50
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> # Hint: longest is a number between 70 and 130.
          >>> 70 <= longest <= 130
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> # Hint: the average is between the shortest and the longest
          >>> shortest <= average <= longest
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
