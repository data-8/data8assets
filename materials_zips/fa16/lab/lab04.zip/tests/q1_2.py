test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> type(mark_hurd_pay_string) == str
          True

          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> mark_hurd_pay_string
          '$53.25 '

          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
