test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> sales.sort(0)
          box ID | fruit name | count sold | price per fruit ($)
          3964   | grape      | 355        | 0.06
          19930  | strawberry | 102        | 0.25
          20532  | strawberry | 25         | 0.15
          29093  | strawberry | 101        | 0.2
          29161  | peach      | 17         | 0.8
          42449  | apple      | 0          | 0.8
          43118  | kiwi       | 3          | 0.5
          52711  | orange     | 35         | 0.6
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
