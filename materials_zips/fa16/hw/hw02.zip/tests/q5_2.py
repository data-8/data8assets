test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> inventory.sort(0)
          box ID | fruit name | count
          25274  | apple      | 20
          26187  | strawberry | 255
          43566  | peach      | 40
          48800  | orange     | 35
          52357  | strawberry | 102
          53686  | kiwi       | 45
          57181  | strawberry | 123
          57930  | grape      | 517
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
