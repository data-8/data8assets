test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> 1900 <= least_democratic_before_1980_ca <= 2016
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': 'import hashlib',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
